//
//  AppDelegate.m
//  SlideOutApplication
//
//  Created by Jean Martin on 11/07/18.
//  Copyright © 2018 Public. All rights reserved.
//

#import "AppDelegate.h"
#import "LeftViewController.h"
#import "RightViewController.h"
#import "MainViewController.h"
#import "RootNavigationController.h"
#import <MMDrawerVisualState.h>

@interface AppDelegate (){
    MMDrawerController *mmDrawerControllerObject;
    RightViewController *rightSideMenuViewControllerObject;
    MainViewController *centerViewController;
    LeftViewController *leftSideDrawerViewController;
}
@property (nonatomic,strong) UIStoryboard *storyboard;
@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application willFinishLaunchingWithOptions:(NSDictionary *)launchOptions{
    self.storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
   
    [self initialDrawerViewControllerSetUp];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(rightSideView:) name:@"RightDrawerSide" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(leftSideView:) name:@"LeftDrawerSide" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(centerView:)    name:@"CenterView" object:nil];
    return YES;
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
   
//    self.window.backgroundColor = [UIColor whiteColor];
//    [self.window makeKeyAndVisible];
  
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {

}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
 
}


- (void)applicationDidBecomeActive:(UIApplication *)application {

}

- (void)applicationWillTerminate:(UIApplication *)application {

}

- (void)initialDrawerViewControllerSetUp {
    
    mmDrawerControllerObject = [self.storyboard instantiateViewControllerWithIdentifier:@"MMDrawerController"];
    rightSideMenuViewControllerObject = [self.storyboard instantiateViewControllerWithIdentifier:@"RightViewController"];
    centerViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"MainViewController"];
    leftSideDrawerViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"LeftViewController"];
    
    UINavigationController *navigationController =[[UINavigationController alloc] initWithRootViewController:centerViewController];
    [mmDrawerControllerObject setCenterViewController:navigationController];
    [mmDrawerControllerObject setLeftDrawerViewController:leftSideDrawerViewController];
    [mmDrawerControllerObject setRightDrawerViewController:rightSideMenuViewControllerObject];
    self.window.rootViewController = mmDrawerControllerObject;
    
    [mmDrawerControllerObject.navigationItem setHidesBackButton:YES];
    [mmDrawerControllerObject.navigationController.navigationBar setHidden:YES];
    [mmDrawerControllerObject.navigationController.navigationBar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
    mmDrawerControllerObject.navigationController.navigationBar.shadowImage = [UIImage new];
    mmDrawerControllerObject.navigationController.navigationBar.translucent = YES;
    [mmDrawerControllerObject setShowsShadow:NO];
    [mmDrawerControllerObject setMaximumRightDrawerWidth:200];
    [mmDrawerControllerObject setMaximumLeftDrawerWidth:300];
    mmDrawerControllerObject.shouldStretchDrawer = NO;
    [mmDrawerControllerObject setOpenDrawerGestureModeMask:MMOpenDrawerGestureModeBezelPanningCenterView];
    [mmDrawerControllerObject setCloseDrawerGestureModeMask:MMCloseDrawerGestureModeAll];
    [mmDrawerControllerObject setDrawerVisualStateBlock:[MMDrawerVisualState slideVisualStateBlock]];
}

-(void)rightSideView:(NSNotification *)notification{
    [mmDrawerControllerObject toggleDrawerSide:MMDrawerSideRight animated:YES completion:nil];
}

-(void)leftSideView:(NSNotification *)notification{
    [mmDrawerControllerObject toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
}

-(void)centerView:(NSNotification *)notification{
    leftSideDrawerViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"LeftViewController"];
    rightSideMenuViewControllerObject = [self.storyboard instantiateViewControllerWithIdentifier:@"RightViewController"];

}

//-(void)redirectMethod{
//
//    self.storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
//
//    self.leftSideDrawerViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"LeftViewController"];
//
//    self.centerViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"MainViewController"];
//
//    self.rightSideDrawerViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"RightViewController"];
//
//    RootNavigationController * navigationController = [[RootNavigationController alloc] initWithRootViewController:self.centerViewController];
//    [navigationController setRestorationIdentifier:@"MMExampleCenterNavigationControllerRestorationKey"];
//
//    UINavigationController * rightSideNavController = [[RootNavigationController alloc] initWithRootViewController:self.rightSideDrawerViewController];
//     [rightSideNavController setRestorationIdentifier:@"MMExampleRightNavigationControllerRestorationKey"];
//
//    UINavigationController * leftSideNavController = [[RootNavigationController alloc] initWithRootViewController:self.leftSideDrawerViewController];
//    [leftSideNavController setRestorationIdentifier:@"MMExampleLeftNavigationControllerRestorationKey"];
//
//    self.drawerController = [[MMDrawerController alloc]
//                             initWithCenterViewController:navigationController
//                             leftDrawerViewController:leftSideNavController
//                             rightDrawerViewController:rightSideNavController];
//    [self.drawerController setShowsShadow:NO];
//    [self.drawerController setRestorationIdentifier:@"MMDrawer"];
//    [self.drawerController setMaximumRightDrawerWidth:200.0];
//    [self.drawerController setOpenDrawerGestureModeMask:MMOpenDrawerGestureModeAll];
//    [self.drawerController setCloseDrawerGestureModeMask:MMCloseDrawerGestureModeAll];
//
//    //    [self.drawerController
//    //     setDrawerVisualStateBlock:^(MMDrawerController *drawerController, MMDrawerSide drawerSide, CGFloat percentVisible) {
//    //         MMDrawerControllerDrawerVisualStateBlock block;
//    //         block = [[MMExampleDrawerVisualStateManager sharedManager]
//    //                  drawerVisualStateBlockForDrawerSide:drawerSide];
//    //         if(block){
//    //             block(drawerController, drawerSide, percentVisible);
//    //         }
//    //     }];
//
//    //    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
//    //
//    //    UIColor * tintColor = [UIColor colorWithRed:29.0/255.0
//    //                                          green:173.0/255.0
//    //                                           blue:234.0/255.0
//    //                                          alpha:1.0];
//    //    [self.window setTintColor:tintColor];
//    //    [self.window setRootViewController:self.drawerController];
//}

//
//- (UIViewController *)application:(UIApplication *)application viewControllerWithRestorationIdentifierPath:(NSArray *)identifierComponents coder:(NSCoder *)coder
//{
//    NSString * key = [identifierComponents lastObject];
//    if([key isEqualToString:@"MMDrawer"]){
//        return self.window.rootViewController;
//    }
//    else if ([key isEqualToString:@"MMExampleCenterNavigationControllerRestorationKey"]) {
//        return ((MMDrawerController *)self.window.rootViewController).centerViewController;
//    }
//    else if ([key isEqualToString:@"MMExampleRightNavigationControllerRestorationKey"]) {
//        return ((MMDrawerController *)self.window.rootViewController).rightDrawerViewController;
//    }
//    else if ([key isEqualToString:@"MMExampleLeftNavigationControllerRestorationKey"]) {
//        return ((MMDrawerController *)self.window.rootViewController).leftDrawerViewController;
//    }
//    else if ([key isEqualToString:@"MMExampleLeftSideDrawerController"]){
//        UIViewController * leftVC = ((MMDrawerController *)self.window.rootViewController).leftDrawerViewController;
//        if([leftVC isKindOfClass:[UINavigationController class]]){
//            return [(UINavigationController*)leftVC topViewController];
//        }
//        else {
//            return leftVC;
//        }
//
//    }
//    else if ([key isEqualToString:@"MMExampleRightSideDrawerController"]){
//        UIViewController * rightVC = ((MMDrawerController *)self.window.rootViewController).rightDrawerViewController;
//        if([rightVC isKindOfClass:[UINavigationController class]]){
//            return [(UINavigationController*)rightVC topViewController];
//        }
//        else {
//            return rightVC;
//        }
//    }
//    return nil;
//}
//
@end
