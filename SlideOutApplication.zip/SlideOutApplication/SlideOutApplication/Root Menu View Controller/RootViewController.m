//
//  RootViewController.m
//  SlideOutApplication
//
//  Created by Jean Martin on 11/07/18.
//  Copyright © 2018 Public. All rights reserved.
//

#import "RootViewController.h"

@interface RootViewController ()

@end

@implementation RootViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    MainViewController * center = [[MainViewController alloc] init];
    UINavigationController * nav = [[UINavigationController alloc] initWithRootViewController:center];
    [self.mm_drawerController setCenterViewController:nav withCloseAnimation:YES completion:nil];

}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    
     
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
   
    
}


@end
