//
//  RightViewController.m
//  SlideOutApplication
//
//  Created by Jean Martin on 11/07/18.
//  Copyright © 2018 Public. All rights reserved.
//

#import "RightViewController.h"
#import "RightTableViewCell.h"

@interface RightViewController (){
    NSMutableArray *titleArray;
}

@end

@implementation RightViewController


- (void)viewDidLoad {
    [super viewDidLoad];
   
    titleArray = [NSMutableArray arrayWithObjects:@"USA",@"UK",@"Spain",@"France",@"England", nil];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return titleArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    RightTableViewCell *rightTableViewCell = [tableView dequeueReusableCellWithIdentifier:@"RightCell" forIndexPath:indexPath];
    
    rightTableViewCell.textLabelRightOutlet.text = titleArray[indexPath.row];
    
    return rightTableViewCell;
}



@end
