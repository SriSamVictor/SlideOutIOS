//
//  RightViewController.h
//  SlideOutApplication
//
//  Created by Jean Martin on 11/07/18.
//  Copyright © 2018 Public. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RightViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *righTableViewOutlet;

@end
