//
//  LeftViewController.h
//  SlideOutApplication
//
//  Created by Jean Martin on 11/07/18.
//  Copyright © 2018 Public. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeftViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *leftTableViewOutlet;

@end
