//
//  LeftViewController.m
//  SlideOutApplication
//
//  Created by Jean Martin on 11/07/18.
//  Copyright © 2018 Public. All rights reserved.
//

#import "LeftViewController.h"
#import "LeftTableViewCell.h"

@interface LeftViewController (){
    NSMutableArray *titleArray;
}

@end

@implementation LeftViewController

-(id)init{
    self = [super init];
    if(self){
        [self setRestorationIdentifier:@"MMExampleLeftSideDrawerController"];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
   
    titleArray = [NSMutableArray arrayWithObjects:@"USA",@"UK",@"Spain",@"France",@"England", nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];

}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return titleArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    LeftTableViewCell *leftTableViewCell = [tableView dequeueReusableCellWithIdentifier:@"LeftCell" forIndexPath:indexPath];
    
    leftTableViewCell.textLabelOutlet.text = titleArray[indexPath.row];
    
    return leftTableViewCell;
    
}

@end
