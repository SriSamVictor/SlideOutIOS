//
//  MainViewController.m
//  SlideOutApplication
//
//  Created by Jean Martin on 11/07/18.
//  Copyright © 2018 Public. All rights reserved.
//

#import "MainViewController.h"
#import "LeftViewController.h"
#import "RightViewController.h"
#import "RootViewController.h"
#import <MMDrawerController/MMDrawerVisualState.h>
#import <MMDrawerController/MMDrawerController.h>
#import <MMDrawerController/UIViewController+MMDrawerController.h>

@interface MainViewController (){
   
}

@end

@implementation MainViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.navigationController setNavigationBarHidden:YES];

}
         
    
-(void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
   
}

- (IBAction)rightButtonAction:(id)sender {

    [[NSNotificationCenter defaultCenter] postNotificationName:@"RightDrawerSide" object:nil];
}

- (IBAction)leftButtonAction:(id)sender {
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"LeftDrawerSide" object:nil];
    
}




@end
