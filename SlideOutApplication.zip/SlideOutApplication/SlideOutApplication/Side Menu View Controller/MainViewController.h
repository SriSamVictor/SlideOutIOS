//
//  MainViewController.h
//  SlideOutApplication
//
//  Created by Jean Martin on 11/07/18.
//  Copyright © 2018 Public. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MMDrawerController/MMDrawerController.h>


@interface MainViewController : UIViewController
- (IBAction)rightButtonAction:(id)sender;
- (IBAction)leftButtonAction:(id)sender;
@end
